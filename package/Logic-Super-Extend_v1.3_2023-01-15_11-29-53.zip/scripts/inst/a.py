# -*- coding: utf-8; -*-

from random import randint

stack = []

while True:
    n = randint(32, 32)
    if len(stack) < 2:
        stack.append(n)
        continue
    print(stack, end="")
    if sum(stack) > 4095:
        break
    if stack[0] > stack[1] + n or stack[0] > stack[1]:
        print(f"right merge({stack[1]}, {n})")
        stack.append(stack.pop() + n)
    else:
        print(f"left merge({stack[0]}, {stack[1]})")
        stack[0] += stack.pop()
        stack.append(n)
print()
