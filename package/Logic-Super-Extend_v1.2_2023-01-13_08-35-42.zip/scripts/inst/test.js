const TestI = {
    new: () => {},
    func(x) {
        return x + " Test.";
    }
}

module.exports = [TestI];