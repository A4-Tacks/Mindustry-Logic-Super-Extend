export const TestI = {
    new: () => {},
    func(x) {
        return x + " Test.";
    }
}