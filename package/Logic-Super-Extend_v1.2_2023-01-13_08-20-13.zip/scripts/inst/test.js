const TestI = {
    func(x) {
        return x + " Test.";
    }
}